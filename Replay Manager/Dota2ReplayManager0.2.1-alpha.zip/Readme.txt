Thank you for downloading Dota2 Replay Manager v0.2.1-alpha

Please visit GitHub page for more updates.
https://github.com/fplayer/Dota2-Replay-Manager/